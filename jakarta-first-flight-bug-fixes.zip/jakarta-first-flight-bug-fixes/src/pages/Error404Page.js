import React from 'react'

const Error404Page = () => {
  return (
      <div>
          <h1>OOPS, PAGE NOT FOUND</h1>
    </div>
  )
}

export default Error404Page;