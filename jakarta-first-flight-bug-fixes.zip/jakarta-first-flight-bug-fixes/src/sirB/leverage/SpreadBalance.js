
const SpreadBalance = (balance) => {
    const today = (new Date()).toDateString();
    
    const l_formular = (bal, key) => ((bal * key) / 1000).toFixed(2);

    const laverageObj = {
        x1: {amount: l_formular(balance, 2), completed: false},
        x2: {amount: l_formular(balance, 5), completed: false},
        x3: {amount: l_formular(balance, 11), completed: false},
        x4: {amount: l_formular(balance, 24), completed: false},
        x5: {amount: l_formular(balance, 55), completed: false},
        x6: {amount: l_formular(balance, 117), completed: false},
        x7: {amount: l_formular(balance, 252), completed: false},
        x8: {amount: l_formular(balance, 534), completed: false},
        updatedAt: today
    };


    return laverageObj
}

export default SpreadBalance
