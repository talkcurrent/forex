import React, { useState, useEffect, useRef } from 'react';
import styled from 'styled-components';
import Divider from '../Divider';
import DivTag from '../DivTag';

const InputText = (props) => {
    const {
        label, color, padding, name, inputType,
        placeholder, id, value, onChange,
        error, iconLeft, iconRight, inputBgc
    } = props;

    const [labelScale, setlabelScale] = useState(0.85);
    const [focused, setfocused] = useState(false);
    const [labelWidth, setlabelWidth] = useState(0);
    const [labelOffsetX, setlabelOffsetX] = useState(0);

    const labelRef = useRef();

    useEffect(() => {
        if (labelWidth > 0) {
            //offset after scaling
            const labelTextOffesetX = (labelWidth - (labelWidth * labelScale)) / 2;
            setlabelOffsetX(labelTextOffesetX);
        }
    }, [labelWidth]);

    useEffect(() => {
        console.info(value);
    }, [value]);

    const onLayout = (rect) => {
        const { width } = rect;
        // This rect is updated on every render 
        // so it's very important to check is past value is nt same as current
        if (labelWidth != width) {
            setlabelWidth(width);
        }
    };

    const handleFocus = () => {
        setfocused(true);
    };
    const handleBlue = () => {
        setfocused(false);
    };

    return (
        <DivTag
            color={ color }
            bgc={ inputBgc }
            bRadius={ "5px 5px 0 0" }
            lHeight={ "normal" }
        >
            <DivTag
                gtc={ iconLeft && iconRight ? "auto 1fr auto" : iconLeft ? "auto 1fr" : iconRight ? "1fr auto" : "1fr" }
                gap={ "2px" }
            >
                { iconLeft ?
                    <DivTag
                        align="center"
                        alignSelf="end"
                        padding="0 5px 5px 5px"
                    >
                        { iconLeft }
                    </DivTag>
                    : "" }
                <DivTag
                    color={ color }
                    position={ "relative" }
                    zIndex={ 1 }
                    padding={ "0 5px" }
                >
                    <DivTag
                        onLayout={ onLayout }
                        opacity={ 0 }
                        lHeight={ 1 }
                        justifySelf={ "start" }
                        transform={ `scale(${labelScale})` }
                    >{ label }</DivTag>

                    <DivTag
                        position={ "absolute" } left={ 0 } top={ 0 } bottom={ 0 } width={ "100%" }
                        align={ "end" } justify={ "start" } zIndex={ "-1" } padding={ "5px 5px 0px 5px" }
                    >
                        <DivTag
                            transition={ "all 0.2s ease-in-out" }
                            transform={
                                value.length || focused ?
                                    `translate(${-labelOffsetX}px, -16px ) scale(${labelScale})`
                                    : `translate(0px, 0px ) scale(1)`
                            }
                            color={ value.length || focused ? "#797979" : "black" }
                        >{ label }</DivTag>
                    </DivTag>

                    <DivTag >
                        <InputTextStyle
                            type={ inputType }
                            name={ name }
                            placeholder={ focused ? placeholder : "" }
                            onChange={ onChange }
                            id={ id }
                            value={ value }
                            autoComplete={ props.autoComplete }
                            autoFocus={ props.autoFocus }
                            style={ { padding, } }
                            onFocus={ handleFocus }
                            onBlur={ handleBlue }
                        />
                    </DivTag>
                </DivTag>
                { iconRight ?
                    <DivTag
                        align="center"
                        alignSelf="end"
                        padding="0 5px 5px 5px"
                    >
                        { iconRight }
                    </DivTag>
                    : "" }
            </DivTag>
            {props.lineIndicator != false ?
                <Divider color={ error ? "indianred" : "silver" } height={ focused || error ? 2 : 1 } scale={ 1 } />
                : "" }
        </DivTag>
    );
};

export default InputText;

const InputTextStyle = styled.input`
    outline: none;
    border: unset;
    background: transparent;
`;