
/**
 * Return seconds.
 * @param {number} hour - A number value
 * 
 */

const HoursToSeconds = (hours) => {
    let seconds = (hours * 60) * 60;
        return seconds;
}

export default HoursToSeconds